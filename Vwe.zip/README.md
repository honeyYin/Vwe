# Vwe
Content Management System
1、Main Constructor
（1）Channel
（2）Paper
（3）Comment
（4）User
2、Technology
  SpringMVC+JPA+JSP
